package com.keycloakk.example.keycloak_exemple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeycloakExempleApplicationTests {

	@Test
	void contextLoads() {
	}

}
