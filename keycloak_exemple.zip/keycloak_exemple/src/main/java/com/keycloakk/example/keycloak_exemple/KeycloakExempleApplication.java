package com.keycloakk.example.keycloak_exemple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeycloakExempleApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeycloakExempleApplication.class, args);
	}

}
